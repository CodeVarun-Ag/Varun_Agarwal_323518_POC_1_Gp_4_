package BASE_CLASSES;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class MyAccount_Firefox {
	WebDriver dr;
	WebDriverWait wait;
		
	public MyAccount_Firefox(WebDriver dr)
	{
		this.dr=dr;
	}
	
	public void launch_firefox_browser_and_url()
	{
		System.setProperty("webdriver.gecko.driver", "geckodriver.exe");
		dr= new FirefoxDriver();
		dr.get("http://automationpractice.com/index.php");
	}

	public void login(String email, String password)
	{	
		wait=  new WebDriverWait(dr, 10);
		dr.findElement(By.xpath("//*[@class='login']")).click();
		dr.findElement(By.xpath("//*[@id='email']")).sendKeys(email);
		dr.findElement(By.xpath("//*[@name='passwd']")).sendKeys(password);
		dr.findElement(By.xpath("//*[@id='SubmitLogin']")).click();
	}	
	
	public String verify_profile()
	{
		wait.until(ExpectedConditions.elementToBeClickable(dr.findElement(By.xpath("//a[@class='account']"))));
		String act_result = dr.findElement(By.xpath("//a[@class='account']")).getText();
		return act_result;
	}

	public void go_to_home()
	{
		dr.findElement(By.xpath("//*[@class='home']")).click();
	}

	public void add_product_1()
	{
		dr.findElement(By.xpath("/html/body/div/div[2]/div/div[2]/div/div[1]/ul[1]/li[1]/div/div[1]/div")).click();
		dr.findElement(By.xpath("/html/body/div/div[2]/div/div[3]/div/div/div/div[4]/form/div/div[3]/div[1]/p/button")).click();
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("/html/body/div/div[1]/header/div[3]/div/div/div[4]/div[1]/div[2]/div[4]/span")));
		dr.findElement(By.xpath("/html/body/div/div[1]/header/div[3]/div/div/div[4]/div[1]/div[2]/div[4]/span")).click();
		dr.findElement(By.xpath("/html/body/div/div[2]/div/div[1]/a[1]")).click();
	}
	
	public void add_product_2()
	{
		dr.findElement(By.xpath("/html/body/div/div[2]/div/div[2]/div/div[1]/ul[1]/li[3]/div/div[2]/h5/a")).click();
		dr.findElement(By.xpath("/html/body/div/div[2]/div/div[3]/div/div/div/div[4]/form/div/div[3]/div[1]/p/button")).click();
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("/html/body/div/div[1]/header/div[3]/div/div/div[4]/div[1]/div[1]/span")));
		dr.findElement(By.xpath("/html/body/div/div[1]/header/div[3]/div/div/div[4]/div[1]/div[1]/span")).click();
		dr.findElement(By.xpath("/html/body/div/div[2]/div/div[1]/a[1]")).click();
	}
	
	public void go_to_cart() {
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("/html/body/div/div[1]/header/div[3]/div/div/div[3]/div/a")));
		dr.findElement(By.xpath("/html/body/div/div[1]/header/div[3]/div/div/div[3]/div/a")).click();
	}
	
	public void increase_quantity_of_2()
	{
		dr.findElement(By.xpath("//*[@id=\"cart_quantity_up_3_13_0_200704\"]")).click();
	}
	
	public String verify_product_1()
	{
		wait.until(ExpectedConditions.textToBePresentInElementLocated(By.xpath("/html/body/div/div[2]/div/div[3]/div/div[2]/table/tbody/tr[1]/td[2]/p/a"),"Faded"));
		String act_result=dr.findElement(By.xpath("/html/body/div/div[2]/div/div[3]/div/div[2]/table/tbody/tr[1]/td[2]/p/a")).getText();
		return act_result;
	}
	
	public String verify_product_2()
	{
		wait.until(ExpectedConditions.textToBePresentInElementLocated(By.xpath("/html/body/div/div[2]/div/div[3]/div/div[2]/table/tbody/tr[2]/td[2]/p/a"),"Printed"));
		String act_res = dr.findElement(By.xpath("/html/body/div/div[2]/div/div[3]/div/div[2]/table/tbody/tr[2]/td[2]/p/a")).getText();
		return act_res;
	}
	
	public double verify_product_1_unitprice()
	{
		String temp;
		double act_result;
		temp =dr.findElement(By.xpath("/html/body/div/div[2]/div/div[3]/div/div[2]/table/tbody/tr[1]/td[4]/span/span")).getText();
		temp=temp.substring(1,temp.length());
		act_result=Double.parseDouble(temp);
		return act_result;
	}
	
	public double verify_product_2_unitprice()
	{
		String temp;
		double act_result;
		temp =dr.findElement(By.xpath("/html/body/div/div[2]/div/div[3]/div/div[2]/table/tbody/tr[2]/td[4]/span/span")).getText();
		temp=temp.substring(1,temp.length());
		act_result=Double.parseDouble(temp);
		return act_result;
	}
	
	public double verify_product_1_total()
	{
		String temp;
		double act_result;
		temp =dr.findElement(By.xpath("//*[@id=\"total_product_price_1_1_200704\"]")).getText();
		temp=temp.substring(1,temp.length());
		act_result=Double.parseDouble(temp);
		return act_result;
	}
	public double verify_product_2_total()
	{
		String temp;
		double act_result;
		wait.until(ExpectedConditions.textToBePresentInElementLocated(By.xpath("//*[@id=\"total_product_price_3_13_200704\"]"), "52.00"));
		temp =dr.findElement(By.xpath("//*[@id=\"total_product_price_3_13_200704\"]")).getText();
		temp=temp.substring(1,temp.length());
		act_result=Double.parseDouble(temp);
		return act_result;
	}
	
	public double verify_total()
	{
		String temp;
		double act_result;
		temp = dr.findElement(By.xpath("//*[@id=\"total_price\"]")).getText();
		temp=temp.substring(1,temp.length());
		act_result=Double.parseDouble(temp);
		return act_result;
	}
	
}
