package TESTNG_TESTS;

import java.net.MalformedURLException;
import java.net.URL;

import org.apache.log4j.Logger;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import BASE_CLASSES.MyAccount_Firefox;

public class TestNG_Class_Firefox {
	MyAccount_Firefox firefox_obj;
	Logger log;
	WebDriver dr;
	String baseURL,nodeURL;
	
	public TestNG_Class_Firefox() {
		log= Logger.getLogger("devpinoyLogger");
	}

	
	@BeforeClass
	public void setup() throws MalformedURLException
	{
		baseURL="http://automationpractice.com/index.php";
		nodeURL="http://172.16.70.250:5566/wd/hub";
		DesiredCapabilities cap = DesiredCapabilities.firefox();
		cap.setBrowserName("firefox");
		cap.setPlatform(Platform.WINDOWS);
		System.setProperty("webdriver.gecko.driver", "geckodriver.exe");
		dr = new RemoteWebDriver(new URL(nodeURL),cap);
		firefox_obj = new MyAccount_Firefox(dr);
		dr.get(baseURL);
	}
	
	
	public void write_log(String l)
	{
		log.info(l);
	}
	
	
	@Test(priority=1)
	public void login_and_verify_login()
	{
		String act_result,result;
		String exp_result ="Varun Agarwal";
		write_log("Entered launch_browser_and_url method");
//		firefox_obj.launch_firefox_browser_and_url();
		write_log("Entered login method");
		firefox_obj.login("varun1234@gmail.com", "qwerty12345");
		write_log("Entered verify_profile method");
		act_result= firefox_obj.verify_profile();
		try
		{
		Assert.assertEquals(act_result, exp_result);
		result="Pass";
		write_log("Expected Result : "+exp_result+"\tActual Result : "+act_result+"\t Test_Result : "+result);
		}
		catch (Exception e) {
			result="Fail";
			write_log("Expected Result : "+exp_result+"\tActual Result : "+act_result+"\t Test_Result : "+result);
		}
		write_log("Entered go_to_home method");
		firefox_obj.go_to_home();
	}
	
	
	@Test(priority=2)
	public void add_to_cart()
	{
		write_log("Entered add_product_1 method");
		firefox_obj.add_product_1();
		write_log("Entered add_product_2 method");
		firefox_obj.add_product_2();
		firefox_obj.go_to_cart();
	}
	
	
	@Test(priority=3)
	public void verify_product_1()
	{
		write_log("Entered verify_product_1 method");
		String act_result,result;
		String exp_result ="Faded Short Sleeve T-shirts";
		act_result=firefox_obj.verify_product_1();
		try {
			Assert.assertEquals(act_result,exp_result);
			result ="Pass";
			write_log("Expected Result : "+exp_result+"\tActual Result : "+act_result+"\t Test_Result : "+result);
			
		} catch (Exception e) {
			result = "Fail";
			write_log("Expected Result : "+exp_result+"\tActual Result : "+act_result+"\t Test_Result : "+result);
		}
	}
	
	
	@Test(priority=4)
	public void verify_product_2()
	{
		write_log("Entered verify_product_2 method");
		String act_result,result;
		String exp_result ="Printed Dress";
		act_result=firefox_obj.verify_product_2();
		try {
			Assert.assertEquals(act_result,exp_result);
			result ="Pass";
			write_log("Expected Result : "+exp_result+"\tActual Result : "+act_result+"\t Test_Result : "+result);
			
		} catch (Exception e) {
			result = "Fail";
			write_log("Expected Result : "+exp_result+"\tActual Result : "+act_result+"\t Test_Result : "+result);
		}
		firefox_obj.increase_quantity_of_2();
	}
	
	
	@Test(priority=5)
	public void verify_unitprice_product_1()
	{
		write_log("Entered verify_unitprice_product_1 method");
		double act_result,exp_result=16.51;
		String result;
		act_result=firefox_obj.verify_product_1_unitprice();
		try {
			Assert.assertEquals(act_result,exp_result);
			result ="Pass";
			write_log("Expected Result : "+exp_result+"\tActual Result : "+act_result+"\t Test_Result : "+result);
			
		} catch (Exception e) {
			result = "Fail";
			write_log("Expected Result : "+exp_result+"\tActual Result : "+act_result+"\t Test_Result : "+result);
		}
		
	}
	
	
	@Test(priority=6)
	public void verify_unitprice_product_2()
	{
		write_log("Entered verify_unitprice_product_2 method");
		double act_result,exp_result=26.00;
		String result;
		act_result=firefox_obj.verify_product_2_unitprice();
		try {
			Assert.assertEquals(act_result,exp_result);
			result ="Pass";
			write_log("Expected Result : "+exp_result+"\tActual Result : "+act_result+"\t Test_Result : "+result);
			
		} catch (Exception e) {
			result = "Fail";
			write_log("Expected Result : "+exp_result+"\tActual Result : "+act_result+"\t Test_Result : "+result);
		}
		
	}
	
	
	
	@Test(priority=7)
	public void verify_total_product_1()
	{
		write_log("Entered verify_total_product_1 method");
		double act_result,exp_result=16.51;
		String result;
		act_result=firefox_obj.verify_product_1_total();
		try {
			Assert.assertEquals(act_result,exp_result);
			result ="Pass";
			write_log("Expected Result : "+exp_result+"\tActual Result : "+act_result+"\t Test_Result : "+result);
			
		} catch (Exception e) {
			result = "Fail";
			write_log("Expected Result : "+exp_result+"\tActual Result : "+act_result+"\t Test_Result : "+result);
		}
	}
	
	
	@Test(priority=8)
	public void verify_total_product_2()
	{
		write_log("Entered verify_total_product_2 method");
		double act_result,exp_result=52.00;
		String result;
		act_result=firefox_obj.verify_product_2_total();
		try {
			Assert.assertEquals(act_result,exp_result);
			result ="Pass";
			write_log("Expected Result : "+exp_result+"\tActual Result : "+act_result+"\t Test_Result : "+result);
			
		} catch (Exception e) {
			result = "Fail";
			write_log("Expected Result : "+exp_result+"\tActual Result : "+act_result+"\t Test_Result : "+result);
		}
	}

	
	@Test(priority=9)
	public void verify_total_amount()
	{
		write_log("Entered verify_total_amount method");
		double act_result,exp_result=70.51;
		String result;
		act_result=firefox_obj.verify_total();
		try {
			Assert.assertEquals(act_result,exp_result);
			result ="Pass";
			write_log("Expected Result : "+exp_result+"\tActual Result : "+act_result+"\t Test_Result : "+result);
			
		} catch (Exception e) {
			result = "Fail";
			write_log("Expected Result : "+exp_result+"\tActual Result : "+act_result+"\t Test_Result : "+result);
		}
}
	
	
///---------------------------Incorrect Test Data
	
//	@Test(priority=1)
//	public void login_and_verify_login()
//	{
//		String act_result,result;
//		String exp_result ="Ravi Kumar";
//		write_log("Entered launch_browser_and_url method");
//		firefox_obj.launch_firefox_browser_and_url();
//		write_log("Entered login method");
//		firefox_obj.login("rockerg7@gmail.com", "qwerty123");
//		write_log("Entered verify_profile method");
//		act_result= firefox_obj.verify_profile();
//		try
//		{
//		Assert.assertEquals(act_result, exp_result);
//		result="Pass";
//		write_log("Expected Result : "+exp_result+"\tActual Result : "+act_result+"\t Test_Result : "+result);
//		}
//		catch (Exception e) {
//			result="Fail";
//			write_log("Expected Result : "+exp_result+"\tActual Result : "+act_result+"\t Test_Result : "+result);
//		}
//		write_log("Entered go_to_home method");
//		firefox_obj.go_to_home();
//	}
//	
//	@Test(priority=2)
//	public void add_to_cart()
//	{
//		write_log("Entered add_product_1 method");
//		firefox_obj.add_product_1();
//		write_log("Entered add_product_2 method");
//		firefox_obj.add_product_2();
//		firefox_obj.go_to_cart();
//	}
//	
//	@Test(priority=3)
//	public void verify_product_1()
//	{
//		write_log("Entered verify_product_1 method");
//		String act_result,result;
//		String exp_result ="Faded Jeans";
//		act_result=firefox_obj.verify_product_1();
//		try {
//			Assert.assertEquals(act_result,exp_result);
//			result ="Pass";
//			write_log("Expected Result : "+exp_result+"\tActual Result : "+act_result+"\t Test_Result : "+result);
//			
//		} catch (Exception e) {
//			result = "Fail";
//			write_log("Expected Result : "+exp_result+"\tActual Result : "+act_result+"\t Test_Result : "+result);
//		}
//	}
//	
//	@Test(priority=4)
//	public void verify_product_2()
//	{
//		write_log("Entered verify_product_2 method");
//		String act_result,result;
//		String exp_result ="Colored Dress";
//		act_result=firefox_obj.verify_product_2();
//		try {
//			Assert.assertEquals(act_result,exp_result);
//			result ="Pass";
//			write_log("Expected Result : "+exp_result+"\tActual Result : "+act_result+"\t Test_Result : "+result);
//			
//		} catch (Exception e) {
//			result = "Fail";
//			write_log("Expected Result : "+exp_result+"\tActual Result : "+act_result+"\t Test_Result : "+result);
//		}
//		firefox_obj.increase_quantity_of_2();
//	}
//	
//	@Test(priority=5)
//	public void verify_unitprice_product_1()
//	{
//		write_log("Entered verify_unitprice_product_1 method");
//		double act_result,exp_result=16.27;
//		String result;
//		act_result=firefox_obj.verify_product_1_unitprice();
//		try {
//			Assert.assertEquals(act_result,exp_result);
//			result ="Pass";
//			write_log("Expected Result : "+exp_result+"\tActual Result : "+act_result+"\t Test_Result : "+result);
//			
//		} catch (Exception e) {
//			result = "Fail";
//			write_log("Expected Result : "+exp_result+"\tActual Result : "+act_result+"\t Test_Result : "+result);
//		}
//		
//	}
//	
//	@Test(priority=6)
//	public void verify_unitprice_product_2()
//	{
//		write_log("Entered verify_unitprice_product_2 method");
//		double act_result,exp_result=86.00;
//		String result;
//		act_result=firefox_obj.verify_product_2_unitprice();
//		try {
//			Assert.assertEquals(act_result,exp_result);
//			result ="Pass";
//			write_log("Expected Result : "+exp_result+"\tActual Result : "+act_result+"\t Test_Result : "+result);
//			
//		} catch (Exception e) {
//			result = "Fail";
//			write_log("Expected Result : "+exp_result+"\tActual Result : "+act_result+"\t Test_Result : "+result);
//		}
//		
//	}
//	
//	
//	
//	@Test(priority=7)
//	public void verify_total_product_1()
//	{
//		write_log("Entered verify_total_product_1 method");
//		double act_result,exp_result=13.21;
//		String result;
//		act_result=firefox_obj.verify_product_1_total();
//		try {
//			Assert.assertEquals(act_result,exp_result);
//			result ="Pass";
//			write_log("Expected Result : "+exp_result+"\tActual Result : "+act_result+"\t Test_Result : "+result);
//			
//		} catch (Exception e) {
//			result = "Fail";
//			write_log("Expected Result : "+exp_result+"\tActual Result : "+act_result+"\t Test_Result : "+result);
//		}
//	}
//	
//	@Test(priority=8)
//	public void verify_total_product_2()
//	{
//		write_log("Entered verify_total_product_2 method");
//		double act_result,exp_result=59.00;
//		String result;
//		act_result=firefox_obj.verify_product_2_total();
//		try {
//			Assert.assertEquals(act_result,exp_result);
//			result ="Pass";
//			write_log("Expected Result : "+exp_result+"\tActual Result : "+act_result+"\t Test_Result : "+result);
//			
//		} catch (Exception e) {
//			result = "Fail";
//			write_log("Expected Result : "+exp_result+"\tActual Result : "+act_result+"\t Test_Result : "+result);
//		}
//	}
//
//	@Test(priority=9)
//	public void verify_total_amount()
//	{
//		write_log("Entered verify_total_amount method");
//		double act_result,exp_result=6.51;
//		String result;
//		act_result=firefox_obj.verify_total();
//		try {
//			Assert.assertEquals(act_result,exp_result);
//			result ="Pass";
//			write_log("Expected Result : "+exp_result+"\tActual Result : "+act_result+"\t Test_Result : "+result);
//			
//		} catch (Exception e) {
//			result = "Fail";
//			write_log("Expected Result : "+exp_result+"\tActual Result : "+act_result+"\t Test_Result : "+result);
//		}
//}
	

	
	
	
}
